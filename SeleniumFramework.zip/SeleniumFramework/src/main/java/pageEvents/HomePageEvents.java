package pageEvents;

import pageObjects.HomePageElements;
import utils.ElementFetch;
import org.testng.Assert;





public class HomePageEvents {
	ElementFetch ele= new ElementFetch();
	public void searchProducts()
	{
		ele.getWebElement("XPATH", HomePageElements.searchbar).click();
		ele.getWebElement("XPATH", HomePageElements.searchbar).sendKeys("iphone");
		ele.getWebElement("XPATH", HomePageElements.searchbutton).click();
		String firstEleTitle= ele.getWebElement("XPATH", HomePageElements.firstElement).getText();
		//String arr[] = firstEleTitle.split(" ", 3);
		//String firstWord = arr[0];   
		
		String firstWord= firstEleTitle.substring(0, 12);
		
		String ExpectedfirstEleTitle= "Apple iPhone";
		Assert.assertEquals(firstWord,ExpectedfirstEleTitle);
		System.out.println("Apple iPhone text is verified successfully");
	}
}
