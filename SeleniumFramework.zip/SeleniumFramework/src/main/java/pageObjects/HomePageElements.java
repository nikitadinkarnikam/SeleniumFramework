package pageObjects;

public interface HomePageElements {
	String searchbar = "//input[@placeholder='Search Amazon']";
	String searchbutton = "//input[@type='submit']";
	String firstElement = "(//span[starts-with(text(), 'Apple iPhone')])[1]";
}
