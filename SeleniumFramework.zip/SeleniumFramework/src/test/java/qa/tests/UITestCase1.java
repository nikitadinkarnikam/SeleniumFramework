package qa.tests;

import org.testng.annotations.Test;

import base.baseTest;
import pageEvents.HomePageEvents;
import utils.ElementFetch;

public class UITestCase1 extends baseTest{
	ElementFetch ele= new ElementFetch();
	HomePageEvents homePage= new HomePageEvents();
  @Test
  public void productsSearch() {
	  homePage.searchProducts();
  }
}
